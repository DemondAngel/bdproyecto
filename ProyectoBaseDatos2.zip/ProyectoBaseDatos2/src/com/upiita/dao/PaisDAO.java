package com.upiita.dao;

import com.upiita.model.Pais;

/**
 *
 * @author ELA ALEINAD
 */
public interface PaisDAO extends DAO<Pais> {

}
