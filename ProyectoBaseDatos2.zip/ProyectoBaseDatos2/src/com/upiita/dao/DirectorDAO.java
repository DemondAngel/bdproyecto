package com.upiita.dao;

import com.upiita.model.Director;

/**
 *
 * @author ELA ALEINAD
 */
public interface DirectorDAO extends DAO<Director> {

}
